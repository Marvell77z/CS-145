//Programmer: Marvell Suhali, Farrel Harten, Rachit Khanderwal, Tam Nguyen
//Class: CS145
//Date: 4/18/2023
//Assignment: Lab 2: Critters
//Purpose: Simulation for animals competing with one another

import java.awt.*;

public class Bear extends Critter { //bear class
    private boolean polar;
    private boolean slash;

    public Bear(boolean polar) {
        this.polar = polar;
        slash = true;
       
    } //bear actions and behaviour
    public Action getMove(CritterInfo info) {
        slash = !slash;
        if (info.getFront() == Neighbor.OTHER) {
            return Action.INFECT;
        } 
        else if (info.getFront() == Neighbor.EMPTY) {
            return Action.HOP;
        }
        return Action.LEFT;
        
    } //bear colour
    public Color getColor() {
        if (polar){
            return Color.WHITE;
        } else {
            return Color.BLACK;
        } //end
        
    } //return value of "/" and "\" of bear
    public String toString() {
        if (slash) { 
        return "/";
        } else {
            return "\\";
        } // end
    }
}