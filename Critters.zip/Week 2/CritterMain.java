//Programmer: Marvell Suhali, Farrel Harten, Rachit Khanderwal, Tam Nguyen
//Class: CS145
//Date: 4/18/2023
//Assignment: Lab 2: Critters
//Purpose: Simulation for animals competing with one another

public class CritterMain {
    public static void main(String[] args) {
        CritterFrame frame = new CritterFrame(60, 40);
        
        frame.add(30, Bear.class);
        frame.add(30, Lion.class);
        frame.add(30, Giant.class);
        frame.add(30, Orca.class);

        frame.add(30, FlyTrap.class);
        frame.add(30, Food.class);

        frame.start();
    }
}
