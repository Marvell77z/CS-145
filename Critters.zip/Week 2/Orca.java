//Programmer: Marvell Suhali, Farrel Harten, Rachit Khanderwal, Tam Nguyen
//Class: CS145
//Date: 4/18/2023
//Assignment: Lab 2: Critters
//Purpose: Simulation for animals competing with one another

import java.awt.*;

public class Orca extends Critter {
    private String orcaSquad = "O"; 
    
    public Orca() {
    } //orca actions
    public Action getMove(CritterInfo info) { //orca's will be stronger as they can infect
        if (info.getFront() == Neighbor.OTHER) { 
            return Action.INFECT;
        } else if (info.getFront() == Neighbor.EMPTY) {
            return Action.HOP;
        }
        return Action.LEFT;
    }

    public Color getColor() { //orca colour
        return Color.PINK;
    }

    public String toString() { //return string
        return orcaSquad; 
    }
}