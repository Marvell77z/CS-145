//Programmer: Marvell Suhali, Farrel Harten, Rachit Khunderwal, Tam Nguyen
//Class: CS145
//Date: 25/4/2023
//Assignment: Lab 3: Deck of Cards
//Purpose: The purpose of this lab is to create a game using deck of cards and the game that I choose is blackjack.

public enum Suit { //to organize the suits
    Clubs,
    Diamonds,
    Spades,
    Hearts,
}
